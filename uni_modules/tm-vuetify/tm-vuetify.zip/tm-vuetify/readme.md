# TM-VUETIFY

### [文档介绍，点此打开](http://jx2d.cn)
### 已经发布了最新版本1.2.23,请使用手机扫码预览体验。
### 1.2.0更新非常的巨大（全新暗黑，全局主题动态实时切换，lottie动画,echarts图表），请结合动图和下载示例程序运行查看效果，你会喜欢的！

#### 关于1.2.23安装说明：

[安装说明](http://localhost:8081/guid/start/%E5%AE%89%E8%A3%85.html)

---

#### 用户群需要回答问题，答案为：tm-vuetify。
#### 贡献群需要回答问题并且得到我的验证才能入群。
![用户群](https://jx2d.cn/yuwuimages/tmUI%E7%94%A8%E6%88%B7%E7%BE%A4%E7%BE%A4%E8%81%8A%E4%BA%8C%E7%BB%B4%E7%A0%81.png)
![贡献群](https://jx2d.cn/yuwuimages/tmUI%E8%B4%A1%E7%8C%AE%E7%BE%A4%E7%BE%A4%E8%81%8A%E4%BA%8C%E7%BB%B4%E7%A0%81.png)

---

### :bomb: 扫码预览
![H5](http://jx2d.cn/uniapp/static/qrprev.png)
![微信小程序](https://jx2d.cn/yuwuimages/weichatapp.jpg)

### :bomb: 特性预览
![自动切换主题](https://jx2d.cn/yuwuimages/themechange.gif)
![暗黑模式切换](https://jx2d.cn/yuwuimages/blacktheme.gif)
![tm-lottie动画演示图片](https://jx2d.cn/yuwuimages/lottie/ani_lottie_play.gif)
![echarts图表](https://jx2d.cn/yuwuimages/echarts.gif)
### :bomb: 1.1.5预览图
![Image](https://jx2d.cn/images/1@2x.jpg)
![Image](https://jx2d.cn/images/2@2x.jpg)

