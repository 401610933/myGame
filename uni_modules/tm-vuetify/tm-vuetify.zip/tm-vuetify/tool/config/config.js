/**
 * 创建时间：2021年7月2日11:24:23
 * 作者：tmzdy
 */
let ver = '1.2.24';
export default {
	v: ver,
	version: ver,
	V:ver,
	ver:ver
}